import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { downloadRequestSchema, urlAnalyzeSchema } from "@shared/schema";
import { z } from "zod";

// Mock ytdl-core functionality for demonstration
const mockYtdlCore = {
  async getInfo(url: string) {
    // Generate realistic YouTube data
    const titles = [
      "Amazing Travel Vlog - Exploring Hidden Gems Around the World",
      "Top 10 Tech Gadgets You Need to Know About in 2024",
      "How to Cook Perfect Homemade Pasta - Chef's Secret Recipe",
      "30 Day Fitness Transformation - Incredible Results",
      "Music Production Tips for Beginners - Complete Guide",
      "Cryptocurrency Analysis - Market Trends and Predictions",
      "DIY Home Improvement Projects That Actually Work",
      "Gaming Review - Is This the Best Game of 2024?",
      "Photography Tutorial - Mastering Natural Light",
      "Business Success Story - From Zero to Million Dollar Company"
    ];
    
    const channels = [
      "TechReviewHub", "TravelWithMe", "CookingMaster", "FitnessJourney", 
      "MusicProTips", "CryptoInsights", "DIYHomeGuru", "GameZoneReviews",
      "PhotoPro", "BusinessSuccess"
    ];
    
    const randomIndex = Math.floor(Math.random() * titles.length);
    const duration = 120 + Math.floor(Math.random() * 600); // 2-12 minutes
    
    return {
      videoDetails: {
        title: titles[randomIndex],
        lengthSeconds: duration.toString(),
        thumbnails: [{ url: `https://i.ytimg.com/vi/dQw4w9WgXcQ/maxresdefault.jpg` }],
        ownerChannelName: channels[randomIndex]
      },
      formats: [
        {
          quality: "1080p",
          container: "mp4",
          hasAudio: true,
          hasVideo: true,
          contentLength: "52428800" // ~50MB
        }
      ]
    };
  },

  async downloadFromInfo(info: any, options: any) {
    // Simulate download stream
    const stream = new (require('stream').Readable)();
    stream.push(null); // End the stream
    return stream;
  }
};

function detectPlatform(url: string): string {
  if (url.includes('youtube.com') || url.includes('youtu.be')) return 'youtube';
  if (url.includes('instagram.com')) return 'instagram';
  if (url.includes('tiktok.com')) return 'tiktok';
  if (url.includes('facebook.com')) return 'facebook';
  if (url.includes('twitch.tv')) return 'twitch';
  return 'unknown';
}

function detectContentType(url: string, format: string): string {
  if (url.includes('instagram.com')) {
    if (url.includes('/stories/')) return 'story';
    if (url.includes('/p/')) return format === 'mp4' ? 'video' : 'image';
    return 'image';
  }
  if (format === 'mp3') return 'video'; // Audio extraction from video
  if (format === 'jpg' || format === 'png') return 'image';
  return 'video';
}

function getAvailableFormats(platform: string): any[] {
  const formats = {
    youtube: [
      { quality: "1080p", format: "mp4", size: "~50MB" },
      { quality: "720p", format: "mp4", size: "~30MB" },
      { quality: "480p", format: "mp4", size: "~20MB" },
      { quality: "360p", format: "mp4", size: "~15MB" },
      { quality: "240p", format: "mp4", size: "~10MB" },
      { quality: "audio", format: "mp3", size: "~5MB" }
    ],
    instagram: [
      { quality: "original", format: "mp4", size: "~25MB" },
      { quality: "original", format: "jpg", size: "~2MB" },
      { quality: "story", format: "mp4", size: "~15MB" },
      { quality: "story", format: "jpg", size: "~1MB" }
    ],
    tiktok: [
      { quality: "original", format: "mp4", size: "~20MB" },
      { quality: "720p", format: "mp4", size: "~15MB" },
      { quality: "audio", format: "mp3", size: "~3MB" }
    ],
    facebook: [
      { quality: "hd", format: "mp4", size: "~40MB" },
      { quality: "sd", format: "mp4", size: "~25MB" },
      { quality: "audio", format: "mp3", size: "~4MB" }
    ],
    twitch: [
      { quality: "source", format: "mp4", size: "~60MB" },
      { quality: "720p", format: "mp4", size: "~35MB" },
      { quality: "480p", format: "mp4", size: "~20MB" },
      { quality: "audio", format: "mp3", size: "~6MB" }
    ]
  };
  return formats[platform as keyof typeof formats] || [];
}

function getRealisticTitle(platform: string, url: string): string {
  const titles = {
    youtube: [
      "Amazing Travel Vlog - Exploring Hidden Gems",
      "Top 10 Tech Gadgets You Need in 2024",
      "Cooking with Love - Homemade Pasta Recipe",
      "Fitness Journey - 30 Day Transformation",
      "Music Production Tips for Beginners"
    ],
    instagram: [
      "Stunning Sunset Photography",
      "Behind the Scenes Fashion Shoot",
      "Daily Workout Routine",
      "Delicious Food Recipe",
      "Travel Adventure Story"
    ],
    tiktok: [
      "Viral Dance Challenge",
      "Comedy Skit - Funny Moments",
      "Life Hacks You Need to Know",
      "Pet Compilation - Cute Animals",
      "Quick Recipe Tutorial"
    ],
    facebook: [
      "Family Reunion Highlights",
      "Business Success Story",
      "Community Event Coverage",
      "Educational Content Series",
      "Product Review and Demo"
    ],
    twitch: [
      "Epic Gaming Moments Compilation",
      "Live Stream Highlights",
      "Speedrun World Record Attempt",
      "Charity Stream Event",
      "Gaming Tutorial and Tips"
    ]
  };
  
  const platformTitles = titles[platform as keyof typeof titles] || ["Sample Content"];
  return platformTitles[Math.floor(Math.random() * platformTitles.length)];
}

function getRealisticThumbnail(platform: string): string {
  const thumbnails = {
    youtube: [
      "https://i.ytimg.com/vi/dQw4w9WgXcQ/maxresdefault.jpg",
      "https://i.ytimg.com/vi/9bZkp7q19f0/maxresdefault.jpg",
      "https://i.ytimg.com/vi/kJQP7kiw5Fk/maxresdefault.jpg",
      "https://i.ytimg.com/vi/fJ9rUzIMcZQ/maxresdefault.jpg"
    ],
    instagram: [
      "https://picsum.photos/320/320?random=1",
      "https://picsum.photos/320/320?random=2",
      "https://picsum.photos/320/320?random=3",
      "https://picsum.photos/320/320?random=4"
    ],
    tiktok: [
      "https://picsum.photos/320/568?random=5",
      "https://picsum.photos/320/568?random=6",
      "https://picsum.photos/320/568?random=7",
      "https://picsum.photos/320/568?random=8"
    ],
    facebook: [
      "https://picsum.photos/320/180?random=9",
      "https://picsum.photos/320/180?random=10",
      "https://picsum.photos/320/180?random=11",
      "https://picsum.photos/320/180?random=12"
    ],
    twitch: [
      "https://picsum.photos/320/180?random=13",
      "https://picsum.photos/320/180?random=14",
      "https://picsum.photos/320/180?random=15",
      "https://picsum.photos/320/180?random=16"
    ]
  };
  
  const platformThumbnails = thumbnails[platform as keyof typeof thumbnails] || ["https://via.placeholder.com/320x180?text=Media+Thumbnail"];
  return platformThumbnails[Math.floor(Math.random() * platformThumbnails.length)];
}

function getRealisticChannel(platform: string): string {
  const channels = {
    youtube: ["TechReviewer", "FoodieChannel", "TravelVlogger", "FitnessGuru", "MusicProducer"],
    instagram: ["@lifestyle_blogger", "@food_photographer", "@travel_addict", "@fitness_model", "@art_creator"],
    tiktok: ["@viral_creator", "@comedy_king", "@dance_star", "@life_hacker", "@pet_lover"],
    facebook: ["Community Page", "Business Official", "News Network", "Educational Hub", "Review Channel"],
    twitch: ["GamerPro", "StreamerElite", "EsportsChamp", "CasualGamer", "SpeedrunMaster"]
  };
  
  const platformChannels = channels[platform as keyof typeof channels] || ["Content Creator"];
  return platformChannels[Math.floor(Math.random() * platformChannels.length)];
}

function generateFilename(title: string, format: string): string {
  // Clean title: remove special characters, replace spaces with underscores
  const cleanTitle = title
    .replace(/[^\w\s-]/g, '') // Remove special characters except spaces and hyphens
    .replace(/\s+/g, '_') // Replace spaces with underscores
    .replace(/-+/g, '-') // Replace multiple hyphens with single
    .replace(/_{2,}/g, '_') // Replace multiple underscores with single
    .substring(0, 50); // Limit length
  
  return `${cleanTitle}.${format}`;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Download request endpoint
  app.post("/api/download", async (req, res) => {
    try {
      const validatedData = downloadRequestSchema.parse(req.body);
      const { url, format } = validatedData;
      
      const platform = detectPlatform(url);
      const contentType = detectContentType(url, format || "mp4");
      
      if (platform === 'unknown') {
        return res.status(400).json({ 
          error: "Unsupported platform. Please use YouTube, Instagram, TikTok, Facebook, or Twitch URLs." 
        });
      }

      // Create download record
      const download = await storage.createDownload({
        url,
        platform,
        contentType,
        format: format || "mp4"
      });

      // Handle all platforms with mock data
      let mockInfo;
      if (platform === 'youtube') {
        mockInfo = await mockYtdlCore.getInfo(url);
      } else {
        // Mock data for other platforms
        mockInfo = {
          videoDetails: {
            title: getRealisticTitle(platform, url),
            lengthSeconds: platform === 'instagram' ? "30" : "120",
            thumbnails: [{ url: getRealisticThumbnail(platform) }],
            ownerChannelName: getRealisticChannel(platform)
          },
          formats: [
            {
              quality: platform === 'instagram' ? 'original' : '720p',
              container: format || 'mp4',
              hasAudio: true,
              hasVideo: true,
              contentLength: "10485760"
            }
          ]
        };
      }

      // Process download for all platforms
      try {
        const videoDetails = mockInfo.videoDetails;
        const bestFormat = mockInfo.formats[0];

        // Generate proper filename
        const filename = generateFilename(videoDetails.title, format || 'mp4');

        // Update download with media metadata
        const updatedDownload = await storage.updateDownloadStatus(download.id, 'processing', {
          title: videoDetails.title,
          duration: `${Math.floor(parseInt(videoDetails.lengthSeconds) / 60)}:${(parseInt(videoDetails.lengthSeconds) % 60).toString().padStart(2, '0')}`,
          thumbnail: videoDetails.thumbnails[0]?.url,
          quality: bestFormat.quality,
          fileSize: bestFormat.contentLength ? `${(parseInt(bestFormat.contentLength) / 1024 / 1024).toFixed(1)} MB` : 'Unknown'
        });

        // Simulate processing delay
        setTimeout(async () => {
          await storage.updateDownloadStatus(download.id, 'completed');
        }, 2000);

        res.json({
          success: true,
          downloadId: download.id,
          filename: filename,
          videoInfo: {
            title: updatedDownload?.title,
            duration: updatedDownload?.duration,
            thumbnail: updatedDownload?.thumbnail,
            quality: updatedDownload?.quality,
            fileSize: updatedDownload?.fileSize
          }
        });

      } catch (error) {
        await storage.updateDownloadStatus(download.id, 'error');
        res.status(500).json({ 
          error: "Failed to process media. Please check the URL and try again.",
          downloadId: download.id
        });
      }

    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: error.errors[0].message 
        });
      }
      
      res.status(500).json({ 
        error: "An unexpected error occurred. Please try again." 
      });
    }
  });

  // Download status endpoint
  app.get("/api/download/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const download = await storage.getDownload(id);
      
      if (!download) {
        return res.status(404).json({ error: "Download not found" });
      }

      res.json({
        id: download.id,
        status: download.status,
        title: download.title,
        platform: download.platform,
        format: download.format,
        quality: download.quality,
        duration: download.duration,
        thumbnail: download.thumbnail,
        fileSize: download.fileSize,
        createdAt: download.createdAt
      });

    } catch (error) {
      res.status(500).json({ error: "Failed to get download status" });
    }
  });

  // URL analyze endpoint - for auto-fetching data without download
  app.post("/api/analyze", async (req, res) => {
    try {
      const validatedData = urlAnalyzeSchema.parse(req.body);
      const { url } = validatedData;
      
      const platform = detectPlatform(url);
      
      if (platform === 'unknown') {
        return res.status(400).json({ 
          error: "Unsupported platform. Please use YouTube, Instagram, TikTok, Facebook, or Twitch URLs." 
        });
      }

      // Get available formats for the platform
      const availableFormats = getAvailableFormats(platform);
      
      // Mock data based on platform
      let mockData;
      
      if (platform === 'youtube') {
        const info = await mockYtdlCore.getInfo(url);
        mockData = {
          title: info.videoDetails.title,
          duration: `${Math.floor(parseInt(info.videoDetails.lengthSeconds) / 60)}:${(parseInt(info.videoDetails.lengthSeconds) % 60).toString().padStart(2, '0')}`,
          thumbnail: info.videoDetails.thumbnails[0]?.url,
          channel: info.videoDetails.ownerChannelName,
          platform,
          availableFormats
        };
      } else {
        // Realistic mock data for other platforms
        mockData = {
          title: getRealisticTitle(platform, url),
          duration: platform === 'instagram' ? (url.includes('stories') ? '0:15' : '1:30') : '2:15',
          thumbnail: getRealisticThumbnail(platform),
          channel: getRealisticChannel(platform),
          platform,
          availableFormats
        };
      }

      res.json({
        success: true,
        data: mockData
      });

    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: error.errors[0].message 
        });
      }
      
      res.status(500).json({ 
        error: "An unexpected error occurred. Please try again." 
      });
    }
  });

  // Recent downloads endpoint
  app.get("/api/downloads/recent", async (req, res) => {
    try {
      const downloads = await storage.getRecentDownloads();
      res.json(downloads);
    } catch (error) {
      res.status(500).json({ error: "Failed to get recent downloads" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
