import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const downloads = pgTable("downloads", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  title: text("title"),
  platform: text("platform").notNull(),
  contentType: text("content_type").notNull(), // video, image, story
  format: text("format").notNull(),
  quality: text("quality"),
  duration: text("duration"),
  thumbnail: text("thumbnail"),
  fileSize: text("file_size"),
  availableFormats: text("available_formats"), // JSON string of available formats
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertDownloadSchema = createInsertSchema(downloads).pick({
  url: true,
  platform: true,
  contentType: true,
  format: true,
});

export const downloadRequestSchema = z.object({
  url: z.string().url("Please enter a valid URL"),
  format: z.enum(["mp4", "mp3", "jpg", "png"]).optional(),
  contentType: z.enum(["video", "image", "story"]).optional(),
  quality: z.string().optional(),
});

export const urlAnalyzeSchema = z.object({
  url: z.string().url("Please enter a valid URL"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertDownload = z.infer<typeof insertDownloadSchema>;
export type Download = typeof downloads.$inferSelect;
export type DownloadRequest = z.infer<typeof downloadRequestSchema>;
