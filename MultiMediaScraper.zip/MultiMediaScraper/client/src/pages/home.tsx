import { useEffect } from "react";
import Header from "@/components/header";
import Hero from "@/components/hero";
import Features from "@/components/features";
import SupportedPlatforms from "@/components/supported-platforms";
import FAQ from "@/components/faq";
import LegalNotice from "@/components/legal-notice";
import Footer from "@/components/footer-new";
import { AdSenseBanner, AdSenseResponsive } from "@/components/adsense";

export default function Home() {
  useEffect(() => {
    // Set page title and meta description
    document.title = "Instatubex - Premium Instagram, YouTube, TikTok Video Downloader | HD Quality";
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', 'Premium media downloader for Instagram, YouTube, TikTok, Facebook, and Twitch. Download videos in HD quality, MP4, MP3 formats with luxury experience. No registration required.');
    }
    
    // Add keywords meta tag
    let keywordsMeta = document.querySelector('meta[name="keywords"]');
    if (!keywordsMeta) {
      keywordsMeta = document.createElement('meta');
      keywordsMeta.setAttribute('name', 'keywords');
      document.head.appendChild(keywordsMeta);
    }
    keywordsMeta.setAttribute('content', 'Instagram video downloader, YouTube downloader, TikTok video download, Facebook video downloader, Twitch clip downloader, HD video download, MP4 download, MP3 converter, social media downloader, free video downloader, premium downloader, Instatubex');
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Hero />
      <AdSenseBanner className="bg-gray-50 py-4" />
      <Features />
      <AdSenseResponsive className="bg-white py-8" />
      <SupportedPlatforms />
      <FAQ />
      <AdSenseBanner className="bg-gray-50 py-4" />
      <LegalNotice />
      <Footer />
    </div>
  );
}
