import { useEffect } from "react";
import Header from "@/components/header";
import Footer from "@/components/footer";

export default function Terms() {
  useEffect(() => {
    document.title = "Terms of Service - Instatubex";
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-gray-900 mb-8">Terms of Service</h1>
          
          <div className="prose prose-lg max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">1. Acceptance of Terms</h2>
              <p className="text-gray-700 mb-4">
                By accessing and using Instatubex, you accept and agree to be bound by the terms and provision of this agreement.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">2. Use License</h2>
              <p className="text-gray-700 mb-4">
                Permission is granted to temporarily download one copy of the materials on Instatubex for personal, non-commercial transitory viewing only.
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-4">
                <li>This is the grant of a license, not a transfer of title</li>
                <li>Under this license you may not modify or copy the materials</li>
                <li>Use the materials for any commercial purpose or for any public display</li>
                <li>Attempt to reverse engineer any software contained on the website</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">3. User Responsibilities</h2>
              <p className="text-gray-700 mb-4">
                Users are solely responsible for ensuring that their use of downloaded content complies with:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-4">
                <li>Copyright laws and intellectual property rights</li>
                <li>Platform terms of service</li>
                <li>Local and international laws</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">4. Prohibited Uses</h2>
              <p className="text-gray-700 mb-4">
                You may not use our service to:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-4">
                <li>Download copyrighted content without permission</li>
                <li>Violate any applicable laws or regulations</li>
                <li>Infringe on the rights of others</li>
                <li>Use the service for commercial purposes without authorization</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">5. Disclaimer</h2>
              <p className="text-gray-700 mb-4">
                The materials on Instatubex are provided on an 'as is' basis. Instatubex makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">6. Limitations</h2>
              <p className="text-gray-700 mb-4">
                In no event shall MediaDownloader Pro or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on MediaDownloader Pro, even if MediaDownloader Pro or a MediaDownloader Pro authorized representative has been notified orally or in writing of the possibility of such damage.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">7. Revisions</h2>
              <p className="text-gray-700 mb-4">
                The materials appearing on MediaDownloader Pro could include technical, typographical, or photographic errors. MediaDownloader Pro does not warrant that any of the materials on its website are accurate, complete, or current. MediaDownloader Pro may make changes to the materials contained on its website at any time without notice.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">8. Contact Information</h2>
              <p className="text-gray-700 mb-4">
                If you have any questions about these Terms of Service, please contact us at legal@instatubex.com
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
