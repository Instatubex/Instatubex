import { useEffect } from "react";
import Header from "@/components/header";
import Footer from "@/components/footer";

export default function DMCA() {
  useEffect(() => {
    document.title = "DMCA Policy - Instatubex";
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-gray-900 mb-8">DMCA Policy</h1>
          
          <div className="prose prose-lg max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Copyright Infringement Policy</h2>
              <p className="text-gray-700 mb-4">
                Instatubex respects the intellectual property rights of others and expects our users to do the same. We will respond to clear notices of alleged copyright infringement that comply with the Digital Millennium Copyright Act (DMCA).
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Notice of Infringement</h2>
              <p className="text-gray-700 mb-4">
                If you believe that your copyrighted work has been copied in a way that constitutes copyright infringement, please provide our Copyright Agent with the following information:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-4">
                <li>A physical or electronic signature of the copyright owner or authorized agent</li>
                <li>Identification of the copyrighted work claimed to have been infringed</li>
                <li>Identification of the material claimed to be infringing and information to locate the material</li>
                <li>Contact information including address, telephone number, and email address</li>
                <li>A statement of good faith belief that the use is not authorized</li>
                <li>A statement that the information is accurate and under penalty of perjury</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Copyright Agent</h2>
              <p className="text-gray-700 mb-4">
                Please send DMCA notices to our designated Copyright Agent:
              </p>
              <div className="bg-gray-100 p-4 rounded-lg mb-4">
                <p className="text-gray-700">
                  <strong>Copyright Agent</strong><br />
                  Instatubex<br />
                  Email: dmca@instatubex.com<br />
                  Subject: DMCA Takedown Notice
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Counter-Notification</h2>
              <p className="text-gray-700 mb-4">
                If you believe that your material was removed or disabled by mistake or misidentification, you may file a counter-notification with our Copyright Agent. The counter-notification must include:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-4">
                <li>Your physical or electronic signature</li>
                <li>Identification of the material that was removed and its location</li>
                <li>A statement under penalty of perjury that you have a good faith belief that the material was removed by mistake</li>
                <li>Your name, address, and telephone number</li>
                <li>A statement that you consent to jurisdiction of the federal district court</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Repeat Infringer Policy</h2>
              <p className="text-gray-700 mb-4">
                Instatubex will terminate the accounts of users who are repeat infringers of copyright in appropriate circumstances.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Disclaimer</h2>
              <p className="text-gray-700 mb-4">
                Instatubex is a premium tool that allows users to download content from Instagram, YouTube, TikTok, Facebook, and Twitch. We do not host, store, or control the content that users download. Users are solely responsible for ensuring that their use of downloaded content complies with applicable copyright laws.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Safe Harbor</h2>
              <p className="text-gray-700 mb-4">
                This DMCA policy is intended to implement the safe harbor provisions of the Digital Millennium Copyright Act. Instatubex reserves the right to modify this policy at any time.
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
