import { useEffect } from "react";
import Header from "@/components/header";
import Footer from "@/components/footer";

export default function Disclaimer() {
  useEffect(() => {
    document.title = "Disclaimer - Instatubex";
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-gray-900 mb-8">Disclaimer</h1>
          
          <div className="prose prose-lg max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">General Disclaimer</h2>
              <p className="text-gray-700 mb-4">
                The information on this website is provided on an "as is" basis. To the fullest extent permitted by law, Instatubex excludes all representations, warranties, obligations, and liabilities arising out of or in connection with the use of this website.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Service Availability</h2>
              <p className="text-gray-700 mb-4">
                Instatubex makes no guarantees regarding:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-4">
                <li>Continuous availability of the service</li>
                <li>Compatibility with all video platforms</li>
                <li>Download speeds or quality</li>
                <li>Absence of technical issues or interruptions</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">User Responsibility</h2>
              <p className="text-gray-700 mb-4">
                Users are solely responsible for:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-4">
                <li>Ensuring compliance with copyright laws</li>
                <li>Respecting platform terms of service</li>
                <li>Using downloaded content legally and ethically</li>
                <li>Verifying the accuracy of any information obtained</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Third-Party Content</h2>
              <p className="text-gray-700 mb-4">
                Instatubex does not:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-4">
                <li>Own or control content on third-party platforms</li>
                <li>Verify the legality of content being downloaded</li>
                <li>Guarantee the accuracy of video metadata</li>
                <li>Assume responsibility for third-party content</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Limitation of Liability</h2>
              <p className="text-gray-700 mb-4">
                Instatubex shall not be liable for any direct, indirect, incidental, special, consequential, or punitive damages arising out of or relating to your use of the service, including but not limited to:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-4">
                <li>Loss of data or downloaded content</li>
                <li>Service interruptions or technical issues</li>
                <li>Copyright infringement claims</li>
                <li>Damages to your device or system</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Educational Purpose</h2>
              <p className="text-gray-700 mb-4">
                This service is provided for educational and personal use only. Instatubex does not encourage or condone:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-4">
                <li>Copyright infringement</li>
                <li>Unauthorized distribution of content</li>
                <li>Commercial use of downloaded materials</li>
                <li>Violation of platform terms of service</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Updates and Changes</h2>
              <p className="text-gray-700 mb-4">
                Instatubex reserves the right to modify, suspend, or discontinue the service at any time without notice. This disclaimer may be updated periodically, and continued use of the service constitutes acceptance of any changes.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Contact</h2>
              <p className="text-gray-700 mb-4">
                If you have any questions about this disclaimer, please contact us at legal@instatubex.com
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
