import { Link } from "wouter";

export default function Footer() {
  const footerLinks = [
    // Column 1: Quick Links
    [
      { name: "Home", href: "#home" },
      { name: "Features", href: "#features" },
      { name: "Supported Sites", href: "#supported" },
      { name: "FAQ", href: "#faq" }
    ],
    // Column 2: Legal
    [
      { name: "Terms of Service", href: "/terms" },
      { name: "Privacy Policy", href: "/privacy" },
      { name: "DMCA Policy", href: "/dmca" },
      { name: "Disclaimer", href: "/disclaimer" }
    ],
    // Column 3: Support
    [
      { name: "Contact Us", href: "#contact" },
      { name: "Help Center", href: "#help" },
      { name: "Report Issue", href: "#report" },
      { name: "Feedback", href: "#feedback" }
    ],
    // Column 4: About
    [
      { name: "About Instatubex", href: "#about" },
      { name: "How It Works", href: "#how-it-works" },
      { name: "Premium Features", href: "#premium" },
      { name: "API Access", href: "#api" }
    ]
  ];

  const columnTitles = ["Quick Links", "Legal", "Support", "About"];

  return (
    <footer className="relative bg-gray-900 text-white py-16 overflow-hidden">
      {/* Luxury background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-purple-900/20 to-pink-900/20"></div>
      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        {/* Brand Section */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <svg width="40" height="40" viewBox="0 0 32 32" className="text-primary">
              <defs>
                <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#3B82F6" />
                  <stop offset="50%" stopColor="#8B5CF6" />
                  <stop offset="100%" stopColor="#EC4899" />
                </linearGradient>
              </defs>
              <rect width="32" height="32" rx="8" fill="url(#logoGradient)" />
              <path d="M8 12h16v2H8zm0 4h16v2H8zm0 4h12v2H8z" fill="white" />
              <circle cx="22" cy="20" r="3" fill="white" />
              <path d="M21 19v2l2-1z" fill="url(#logoGradient)" />
            </svg>
            <span className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
              Instatubex
            </span>
          </div>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Premium media downloader for Instagram videos, photos, stories, YouTube, TikTok, Facebook, and Twitch. 
            Experience luxury in simplicity with our cutting-edge technology.
          </p>
        </div>

        {/* 4x4 Grid Layout */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          {footerLinks.map((column, columnIndex) => (
            <div key={columnIndex} className="space-y-4">
              <h3 className="text-lg font-semibold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
                {columnTitles[columnIndex]}
              </h3>
              <ul className="space-y-3">
                {column.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    {link.href.startsWith('#') ? (
                      <a 
                        href={link.href}
                        className="text-gray-300 hover:text-white transition-colors duration-300 text-sm hover:underline"
                      >
                        {link.name}
                      </a>
                    ) : (
                      <Link 
                        href={link.href}
                        className="text-gray-300 hover:text-white transition-colors duration-300 text-sm hover:underline"
                      >
                        {link.name}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Social Media Links */}
        <div className="flex justify-center space-x-6 mb-8">
          <a href="#" className="text-gray-400 hover:text-purple-300 transition-colors duration-300 text-2xl">
            <i className="fab fa-twitter"></i>
          </a>
          <a href="#" className="text-gray-400 hover:text-purple-300 transition-colors duration-300 text-2xl">
            <i className="fab fa-facebook"></i>
          </a>
          <a href="#" className="text-gray-400 hover:text-purple-300 transition-colors duration-300 text-2xl">
            <i className="fab fa-instagram"></i>
          </a>
          <a href="#" className="text-gray-400 hover:text-purple-300 transition-colors duration-300 text-2xl">
            <i className="fab fa-youtube"></i>
          </a>
          <a href="#" className="text-gray-400 hover:text-purple-300 transition-colors duration-300 text-2xl">
            <i className="fab fa-tiktok"></i>
          </a>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-700 pt-8 text-center">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-gray-400 text-sm">
              © 2024 Instatubex. All rights reserved.
            </p>
            <div className="flex space-x-6 text-sm">
              <Link href="/terms" className="text-gray-400 hover:text-white transition-colors">
                Terms
              </Link>
              <Link href="/privacy" className="text-gray-400 hover:text-white transition-colors">
                Privacy
              </Link>
              <Link href="/dmca" className="text-gray-400 hover:text-white transition-colors">
                DMCA
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}