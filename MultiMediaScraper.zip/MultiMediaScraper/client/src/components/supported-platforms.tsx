const platforms = [
  {
    name: "YouTube",
    icon: "fab fa-youtube",
    color: "text-red-600",
    bgColor: "bg-red-100",
    description: "Videos & Shorts"
  },
  {
    name: "Instagram",
    icon: "fab fa-instagram",
    color: "text-pink-600",
    bgColor: "bg-pink-100",
    description: "Videos, Photos & Stories"
  },
  {
    name: "TikTok",
    icon: "fab fa-tiktok",
    color: "text-gray-900",
    bgColor: "bg-gray-100",
    description: "Videos & Sounds"
  },
  {
    name: "Facebook",
    icon: "fab fa-facebook",
    color: "text-blue-600",
    bgColor: "bg-blue-100",
    description: "Videos & Watch"
  },
  {
    name: "Twitch",
    icon: "fab fa-twitch",
    color: "text-purple-600",
    bgColor: "bg-purple-100",
    description: "Clips & VODs"
  }
];

export default function SupportedPlatforms() {
  return (
    <section id="supported" className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Supported Platforms</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Download videos, photos, and stories from all major social media platforms with just one click.
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          {platforms.map((platform, index) => (
            <div key={index} className="text-center">
              <div className={`w-20 h-20 ${platform.bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
                <i className={`${platform.icon} ${platform.color} text-3xl`}></i>
              </div>
              <h3 className="font-semibold">{platform.name}</h3>
              <p className="text-sm text-gray-600">{platform.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
