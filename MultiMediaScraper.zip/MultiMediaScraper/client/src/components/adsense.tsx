import { useEffect } from 'react';

interface AdSenseProps {
  adSlot: string;
  adFormat?: 'auto' | 'rectangle' | 'horizontal' | 'vertical';
  adStyle?: React.CSSProperties;
  className?: string;
}

export default function AdSense({ adSlot, adFormat = 'auto', adStyle, className = '' }: AdSenseProps) {
  useEffect(() => {
    // Load AdSense script if not already loaded
    if (!document.querySelector('script[src*="pagead2.googlesyndication.com"]')) {
      const script = document.createElement('script');
      script.async = true;
      script.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4530652529995026';
      script.crossOrigin = 'anonymous';
      document.head.appendChild(script);
    }

    // Initialize the ad
    try {
      if (window.adsbygoogle) {
        window.adsbygoogle.push({});
      }
    } catch (error) {
      console.error('AdSense initialization error:', error);
    }
  }, []);

  return (
    <div className={`adsense-container ${className}`} style={adStyle}>
      <ins
        className="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client="ca-pub-4530652529995026"
        data-ad-slot={adSlot}
        data-ad-format={adFormat}
        data-full-width-responsive="true"
      />
    </div>
  );
}

// AdSense banner component for header/footer
export function AdSenseBanner({ className = '' }: { className?: string }) {
  return (
    <AdSense
      adSlot="1234567890"
      adFormat="horizontal"
      className={`w-full max-w-4xl mx-auto my-4 ${className}`}
    />
  );
}

// AdSense rectangle component for sidebar/content
export function AdSenseRectangle({ className = '' }: { className?: string }) {
  return (
    <AdSense
      adSlot="0987654321"
      adFormat="rectangle"
      className={`w-full max-w-sm mx-auto my-4 ${className}`}
    />
  );
}

// AdSense responsive component
export function AdSenseResponsive({ className = '' }: { className?: string }) {
  return (
    <AdSense
      adSlot="1357924680"
      adFormat="auto"
      className={`w-full my-6 ${className}`}
    />
  );
}

// Declare global adsbygoogle
declare global {
  interface Window {
    adsbygoogle: any[];
  }
}