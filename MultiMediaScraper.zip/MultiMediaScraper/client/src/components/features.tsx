import { Zap, Shield, Smartphone, Settings, Infinity, UserX } from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "Premium Speed",
    description: "Lightning-fast downloads with enterprise-grade servers and advanced optimization for Instagram, YouTube, and TikTok.",
    color: "bg-primary"
  },
  {
    icon: Shield,
    title: "Military-Grade Security",
    description: "Your privacy is our priority. Advanced encryption, no data retention, and secure processing for all platforms.",
    color: "bg-success"
  },
  {
    icon: Smartphone,
    title: "Cross-Platform Excellence",
    description: "Seamless experience across all devices. Download from any platform on your phone, tablet, or desktop.",
    color: "bg-secondary"
  },
  {
    icon: Settings,
    title: "Premium Quality Options",
    description: "HD, Full HD, 4K video downloads and high-quality MP3 audio extraction from all supported platforms.",
    color: "bg-purple-600"
  },
  {
    icon: Infinity,
    title: "Unlimited Access",
    description: "No restrictions, no limits. Premium experience with unlimited downloads from all supported platforms.",
    color: "bg-indigo-600"
  },
  {
    icon: UserX,
    title: "Instant Access",
    description: "Start downloading immediately. No registration, no waiting, just premium media downloading experience.",
    color: "bg-green-600"
  }
];

export default function Features() {
  return (
    <section id="features" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose Instatubex?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Experience premium media downloading with luxury features, advanced security, and unmatched performance.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center">
              <div className={`w-16 h-16 ${feature.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                <feature.icon className="text-white text-2xl" size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
