import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, Music, Video, Loader2, Image } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { downloadRequestSchema, type DownloadRequest } from "@shared/schema";
import { trackEvent } from "@/lib/analytics";

interface Platform {
  id: string;
  name: string;
  icon: string;
  placeholder: string;
  color: string;
}

const platforms: Platform[] = [
  {
    id: "youtube",
    name: "YouTube",
    icon: "fab fa-youtube",
    placeholder: "https://www.youtube.com/watch?v=example",
    color: "text-red-600"
  },
  {
    id: "instagram",
    name: "Instagram",
    icon: "fab fa-instagram",
    placeholder: "https://www.instagram.com/p/... or /stories/...",
    color: "text-pink-600"
  },
  {
    id: "tiktok",
    name: "TikTok",
    icon: "fab fa-tiktok",
    placeholder: "https://www.tiktok.com/@user/video/example",
    color: "text-gray-900"
  },
  {
    id: "facebook",
    name: "Facebook",
    icon: "fab fa-facebook",
    placeholder: "https://www.facebook.com/watch/?v=example",
    color: "text-blue-600"
  },
  {
    id: "twitch",
    name: "Twitch",
    icon: "fab fa-twitch",
    placeholder: "https://www.twitch.tv/videos/example",
    color: "text-purple-600"
  }
];

export default function DownloadForm() {
  const [selectedPlatform, setSelectedPlatform] = useState<Platform>(platforms[0]);
  const [downloadId, setDownloadId] = useState<number | null>(null);
  const [progress, setProgress] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<DownloadRequest>({
    resolver: zodResolver(downloadRequestSchema),
    defaultValues: {
      url: "",
      format: "mp4"
    }
  });

  // Poll download status
  const { data: downloadStatus } = useQuery({
    queryKey: ["/api/download", downloadId],
    enabled: !!downloadId,
    refetchInterval: (data) => {
      if (data?.status === "completed" || data?.status === "error") {
        return false;
      }
      return 1000;
    }
  });

  const downloadMutation = useMutation({
    mutationFn: async (data: DownloadRequest) => {
      const response = await apiRequest("POST", "/api/download", data);
      return response.json();
    },
    onSuccess: (data) => {
      if (data.downloadId) {
        setDownloadId(data.downloadId);
        setProgress(25);
        
        // Track successful download initiation
        trackEvent('download_initiated', 'video', selectedPlatform.id);
        
        toast({
          title: "Download Started",
          description: "Processing your video..."
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Download Failed",
        description: error.message || "Please check the URL and try again.",
        variant: "destructive"
      });
    }
  });

  // Update progress based on download status
  useEffect(() => {
    if (downloadStatus) {
      switch (downloadStatus.status) {
        case "processing":
          setProgress(50);
          break;
        case "completed":
          setProgress(100);
          toast({
            title: "Download Ready",
            description: "Your video is ready to download!"
          });
          trackEvent('download_completed', 'video', selectedPlatform.id);
          break;
        case "error":
          setProgress(0);
          toast({
            title: "Download Failed",
            description: "There was an error processing your video.",
            variant: "destructive"
          });
          break;
      }
    }
  }, [downloadStatus, toast, selectedPlatform.id]);

  const onSubmit = (data: DownloadRequest) => {
    setDownloadId(null);
    setProgress(0);
    downloadMutation.mutate(data);
  };

  const handlePlatformChange = (platform: Platform) => {
    setSelectedPlatform(platform);
    form.setValue("url", "");
  };

  return (
    <Card className="luxury-card rounded-2xl p-8 text-gray-900 max-w-3xl mx-auto">
      <CardContent className="p-0">
        <div className="mb-6">
          <h2 className="text-2xl font-semibold mb-4">Paste your media URL</h2>
          
          {/* Platform Selection */}
          <div className="flex flex-wrap gap-2 mb-4 justify-center">
            {platforms.map((platform) => (
              <button
                key={platform.id}
                type="button"
                onClick={() => handlePlatformChange(platform)}
                className={`platform-btn ${selectedPlatform.id === platform.id ? 'active' : ''}`}
              >
                <i className={`${platform.icon} ${platform.color} mr-2`}></i>
                {platform.name}
              </button>
            ))}
          </div>
          
          {/* Download Form */}
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {/* URL Input */}
            <div className="flex gap-2">
              <Input
                {...form.register("url")}
                placeholder={selectedPlatform.placeholder}
                className="flex-1"
                disabled={downloadMutation.isPending}
              />
              <Button 
                type="submit" 
                disabled={downloadMutation.isPending}
                className="px-6"
              >
                {downloadMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Download className="w-4 h-4 mr-2" />
                )}
                Download
              </Button>
            </div>
            
            {/* Format Selection */}
            <div className="flex gap-4 justify-center flex-wrap">
              <label className="flex items-center cursor-pointer">
                <input 
                  type="radio" 
                  value="mp4"
                  {...form.register("format")}
                  className="mr-2"
                  disabled={downloadMutation.isPending}
                />
                <Video className="w-4 h-4 mr-1" />
                MP4 Video
              </label>
              <label className="flex items-center cursor-pointer">
                <input 
                  type="radio" 
                  value="mp3"
                  {...form.register("format")}
                  className="mr-2"
                  disabled={downloadMutation.isPending}
                />
                <Music className="w-4 h-4 mr-1" />
                MP3 Audio
              </label>
              {selectedPlatform.id === "instagram" && (
                <>
                  <label className="flex items-center cursor-pointer">
                    <input 
                      type="radio" 
                      value="jpg"
                      {...form.register("format")}
                      className="mr-2"
                      disabled={downloadMutation.isPending}
                    />
                    <Image className="w-4 h-4 mr-1" />
                    JPG Image
                  </label>
                  <label className="flex items-center cursor-pointer">
                    <input 
                      type="radio" 
                      value="png"
                      {...form.register("format")}
                      className="mr-2"
                      disabled={downloadMutation.isPending}
                    />
                    <Image className="w-4 h-4 mr-1" />
                    PNG Image
                  </label>
                </>
              )}
            </div>
          </form>
          
          {/* Progress Bar */}
          {progress > 0 && (
            <div className="mt-4">
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span>Processing...</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="w-full" />
            </div>
          )}
          
          {/* Download Results */}
          {downloadStatus && downloadStatus.status === "completed" && (
            <div className="mt-4">
              <Card className="bg-gray-50 border">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-24 h-16 bg-gray-300 rounded flex items-center justify-center">
                      {downloadStatus.thumbnail ? (
                        <img 
                          src={downloadStatus.thumbnail} 
                          alt="Video thumbnail"
                          className="w-full h-full object-cover rounded"
                        />
                      ) : (
                        <Video className="text-gray-600" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">
                        {downloadStatus.title || "Video Title"}
                      </h3>
                      <p className="text-sm text-gray-600">
                        Duration: {downloadStatus.duration || "Unknown"}
                      </p>
                      <p className="text-sm text-gray-600">
                        Quality: {downloadStatus.quality || "Unknown"}
                      </p>
                      {downloadStatus.fileSize && (
                        <p className="text-sm text-gray-600">
                          Size: {downloadStatus.fileSize}
                        </p>
                      )}
                    </div>
                    <Button 
                      className="bg-success hover:bg-success/90"
                      onClick={() => {
                        toast({
                          title: "Download Starting",
                          description: "Your file will begin downloading shortly."
                        });
                        trackEvent('download_file', 'video', form.getValues("format"));
                      }}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
