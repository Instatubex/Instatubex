import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

interface FAQItem {
  question: string;
  answer: string;
}

const faqItems: FAQItem[] = [
  {
    question: "Is it free to use?",
    answer: "Yes, our service is completely free. You can download unlimited videos without any charges or registration."
  },
  {
    question: "What video quality can I download?",
    answer: "We support multiple video qualities including HD (720p), Full HD (1080p), and 4K when available. The quality depends on the original video uploaded to the platform."
  },
  {
    question: "Is it safe to download videos?",
    answer: "Yes, our service is completely safe. We use secure servers, don't store your data, and all downloads are encrypted. However, always respect copyright laws and platform terms of service."
  },
  {
    question: "Do I need to install any software?",
    answer: "No installation required! Our service works entirely in your web browser. Just paste the URL and download directly to your device."
  },
  {
    question: "Which platforms are supported?",
    answer: "We currently support YouTube with full functionality. Support for Instagram, TikTok, Facebook, and Twitch is coming soon."
  },
  {
    question: "Can I download audio only?",
    answer: "Yes! You can choose to download videos in MP4 format or extract audio in MP3 format. Perfect for music, podcasts, or any audio content."
  }
];

export default function FAQ() {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  return (
    <section id="faq" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Find answers to common questions about our video downloading service.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          {faqItems.map((item, index) => (
            <div key={index} className="mb-6">
              <button
                className="w-full text-left bg-gray-50 p-4 rounded-lg hover:bg-gray-100 transition-colors"
                onClick={() => toggleItem(index)}
              >
                <div className="flex justify-between items-center">
                  <h3 className="font-semibold text-gray-900">{item.question}</h3>
                  {openItems.includes(index) ? (
                    <ChevronUp className="text-gray-500" size={20} />
                  ) : (
                    <ChevronDown className="text-gray-500" size={20} />
                  )}
                </div>
              </button>
              {openItems.includes(index) && (
                <div className="bg-gray-50 px-4 pb-4 rounded-lg">
                  <p className="text-gray-600 pt-4">{item.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
