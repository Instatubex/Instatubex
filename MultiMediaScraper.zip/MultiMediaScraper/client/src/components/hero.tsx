import DownloadFormEnhanced from "@/components/download-form-enhanced";

export default function Hero() {
  return (
    <section id="home" className="relative py-24 overflow-hidden">
      {/* Luxury gradient background */}
      <div className="absolute inset-0 luxury-gradient"></div>
      
      {/* Glass morphism overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-purple-900/20"></div>
      
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-pink-500/20 rounded-full blur-3xl animate-pulse delay-700"></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-5xl mx-auto text-center text-white">
          <div className="mb-8">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              <span className="bg-gradient-to-r from-white via-purple-100 to-pink-100 bg-clip-text text-transparent">
                Premium Media
              </span>
              <br />
              <span className="bg-gradient-to-r from-pink-100 via-purple-100 to-white bg-clip-text text-transparent">
                Downloader
              </span>
            </h1>
            <p className="text-xl md:text-2xl mb-4 opacity-90 font-light">
              Experience luxury in media downloading
            </p>
            <p className="text-lg opacity-80 max-w-2xl mx-auto">
              Download Instagram videos, photos, stories, YouTube content, TikTok videos, Facebook media, and Twitch clips 
              with premium quality and speed. No registration required.
            </p>
          </div>
          
          <DownloadFormEnhanced />
          
          <div className="mt-12 flex flex-wrap justify-center gap-6 text-sm opacity-75">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span>100% Free</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
              <span>HD Quality</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
              <span>Instagram Stories</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-pink-400 rounded-full"></div>
              <span>All Devices</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
              <span>No Watermarks</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
