import { AlertTriangle } from "lucide-react";
import { Link } from "wouter";

export default function LegalNotice() {
  return (
    <section className="py-12 bg-yellow-50 border-t border-yellow-200">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center mb-4">
            <AlertTriangle className="text-yellow-600 text-2xl mr-3" />
            <h2 className="text-xl font-bold text-yellow-800">Important Legal Notice</h2>
          </div>
          <p className="text-yellow-700 mb-4">
            Instatubex is provided for personal use only. Users are responsible for complying with copyright laws and platform terms of service. 
            Only download content you own or have permission to download from Instagram, YouTube, TikTok, and other platforms.
          </p>
          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <Link href="/terms" className="text-yellow-800 hover:text-yellow-900 underline">
              Terms of Service
            </Link>
            <Link href="/privacy" className="text-yellow-800 hover:text-yellow-900 underline">
              Privacy Policy
            </Link>
            <Link href="/dmca" className="text-yellow-800 hover:text-yellow-900 underline">
              DMCA Policy
            </Link>
            <Link href="/disclaimer" className="text-yellow-800 hover:text-yellow-900 underline">
              Disclaimer
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
