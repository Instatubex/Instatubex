import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { downloadRequestSchema, urlAnalyzeSchema, type DownloadRequest } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Download, Play, Clock, User, Loader2, Music, Video, FileImage, Check } from "lucide-react";
import { trackEvent } from "@/lib/analytics";

interface Platform {
  id: string;
  name: string;
  icon: string;
  placeholder: string;
  color: string;
}

interface MediaData {
  title: string;
  duration?: string;
  thumbnail: string;
  channel: string;
  platform: string;
  availableFormats: {
    quality: string;
    format: string;
    size: string;
  }[];
}

interface SelectedFormat {
  quality: string;
  format: string;
  size: string;
}

const platforms: Platform[] = [
  {
    id: "youtube",
    name: "YouTube",
    icon: "fab fa-youtube",
    placeholder: "https://www.youtube.com/watch?v=example",
    color: "text-red-600"
  },
  {
    id: "instagram",
    name: "Instagram",
    icon: "fab fa-instagram",
    placeholder: "https://www.instagram.com/p/... or /stories/...",
    color: "text-pink-600"
  },
  {
    id: "tiktok",
    name: "TikTok",
    icon: "fab fa-tiktok",
    placeholder: "https://www.tiktok.com/@user/video/example",
    color: "text-gray-900"
  },
  {
    id: "facebook",
    name: "Facebook",
    icon: "fab fa-facebook",
    placeholder: "https://www.facebook.com/watch/?v=example",
    color: "text-blue-600"
  },
  {
    id: "twitch",
    name: "Twitch",
    icon: "fab fa-twitch",
    placeholder: "https://www.twitch.tv/videos/example",
    color: "text-purple-600"
  }
];

export default function DownloadFormEnhanced() {
  const [selectedPlatform, setSelectedPlatform] = useState<Platform>(platforms[0]);
  const [url, setUrl] = useState("");
  const [mediaData, setMediaData] = useState<MediaData | null>(null);
  const [selectedFormat, setSelectedFormat] = useState<SelectedFormat | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<{ [key: string]: number }>({});
  const [completedDownloads, setCompletedDownloads] = useState<Set<string>>(new Set());
  const { toast } = useToast();

  const { register, handleSubmit, watch, formState: { errors } } = useForm<{ url: string }>({
    resolver: zodResolver(urlAnalyzeSchema),
    defaultValues: { url: "" }
  });

  const watchedUrl = watch("url");

  // Auto-analyze URL when it changes
  useEffect(() => {
    if (watchedUrl && watchedUrl.length > 10) {
      const timer = setTimeout(() => {
        analyzeUrl(watchedUrl);
      }, 1000);
      return () => clearTimeout(timer);
    } else {
      setMediaData(null);
      setSelectedFormat(null);
    }
  }, [watchedUrl]);

  const analyzeUrl = async (urlToAnalyze: string) => {
    setIsAnalyzing(true);
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ url: urlToAnalyze })
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.success) {
        setMediaData(data.data);
        setUrl(urlToAnalyze);
        // Auto-select first format
        if (data.data.availableFormats.length > 0) {
          setSelectedFormat(data.data.availableFormats[0]);
        }
        trackEvent('url_analyzed', 'media', data.data.platform);
      }
    } catch (error) {
      console.error("Analysis failed:", error);
      setMediaData(null);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const downloadMutation = useMutation({
    mutationFn: async (data: DownloadRequest) => {
      const response = await fetch("/api/download", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        const formatKey = `${selectedFormat?.quality}-${selectedFormat?.format}`;
        setDownloadProgress(prev => ({ ...prev, [formatKey]: 0 }));
        
        // Simulate download progress
        let progress = 0;
        const interval = setInterval(() => {
          progress += Math.random() * 15 + 5; // 5-20% increments
          if (progress >= 100) {
            progress = 100;
            clearInterval(interval);
            setCompletedDownloads(prev => new Set([...prev, formatKey]));
            
            // Show completion with filename
            const filename = data.filename || `${mediaData?.title?.replace(/\s+/g, '_')}.${selectedFormat?.format}`;
            toast({
              title: "Download Complete!",
              description: `File saved as: ${filename}`,
            });
          }
          setDownloadProgress(prev => ({ ...prev, [formatKey]: progress }));
        }, 400);
        
        trackEvent('download_started', 'media', mediaData?.platform);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Download Failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleDownload = (format: SelectedFormat) => {
    if (!mediaData) return;
    
    setSelectedFormat(format);
    
    // AdSense interstitial simulation (70% chance)
    const showAd = Math.random() > 0.3;
    
    if (showAd) {
      // Show ad notification
      toast({
        title: "Loading Advertisement",
        description: "Please wait a moment...",
        duration: 3000,
      });
      
      // Simulate ad display time
      setTimeout(() => {
        toast({
          title: "Advertisement Complete",
          description: "Starting your download now...",
          duration: 1500,
        });
        
        // Start download after ad
        setTimeout(() => {
          downloadMutation.mutate({
            url,
            format: format.format as any,
            quality: format.quality,
            contentType: format.format === 'mp3' ? 'video' : 
                         format.format === 'jpg' || format.format === 'png' ? 'image' : 'video'
          });
        }, 1500);
      }, 3000);
    } else {
      // Direct download without ad
      downloadMutation.mutate({
        url,
        format: format.format as any,
        quality: format.quality,
        contentType: format.format === 'mp3' ? 'video' : 
                     format.format === 'jpg' || format.format === 'png' ? 'image' : 'video'
      });
    }
  };

  const handlePlatformChange = (platform: Platform) => {
    setSelectedPlatform(platform);
    setMediaData(null);
    setSelectedFormat(null);
  };

  const getFormatIcon = (format: string) => {
    switch (format) {
      case 'mp3': return Music;
      case 'mp4': return Video;
      case 'jpg':
      case 'png': return FileImage;
      default: return Video;
    }
  };

  const getQualityBadgeColor = (quality: string) => {
    switch (quality) {
      case '1080p': return 'bg-purple-500';
      case '720p': return 'bg-blue-500';
      case '480p': return 'bg-green-500';
      case '360p': return 'bg-yellow-500';
      case 'audio': return 'bg-pink-500';
      case 'original': return 'bg-indigo-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* URL Input Section */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader>
          <CardTitle className="text-white">Enter Media URL</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Platform Selection */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {platforms.map((platform) => (
              <button
                key={platform.id}
                onClick={() => handlePlatformChange(platform)}
                className={`p-3 rounded-lg border transition-all ${
                  selectedPlatform.id === platform.id
                    ? 'border-purple-400 bg-purple-500/20'
                    : 'border-white/20 bg-white/5 hover:bg-white/10'
                }`}
              >
                <i className={`${platform.icon} ${platform.color} text-2xl mb-2`}></i>
                <div className="text-white text-sm font-medium">{platform.name}</div>
              </button>
            ))}
          </div>

          {/* URL Input */}
          <form onSubmit={handleSubmit(() => {})} className="space-y-2">
            <div className="relative">
              <Input
                {...register("url")}
                placeholder={selectedPlatform.placeholder}
                className="bg-white/10 border-white/20 text-white placeholder-white/50 pr-12"
              />
              {isAnalyzing && (
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <Loader2 className="w-5 h-5 animate-spin text-white" />
                </div>
              )}
            </div>
            {errors.url && (
              <p className="text-red-400 text-sm">{errors.url.message}</p>
            )}
          </form>
        </CardContent>
      </Card>

      {/* Media Information and Download Grid */}
      {mediaData && (
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardHeader>
            <div className="flex items-start space-x-4">
              <img
                src={mediaData.thumbnail}
                alt={mediaData.title}
                className="w-32 h-24 object-cover rounded-lg"
              />
              <div className="flex-1">
                <CardTitle className="text-white text-lg mb-2">{mediaData.title}</CardTitle>
                <div className="flex items-center space-x-4 text-white/70 text-sm">
                  <div className="flex items-center space-x-1">
                    <User className="w-4 h-4" />
                    <span>{mediaData.channel}</span>
                  </div>
                  {mediaData.duration && (
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{mediaData.duration}</span>
                    </div>
                  )}
                  <Badge variant="secondary" className={`${selectedPlatform.color} bg-white/20`}>
                    {mediaData.platform}
                  </Badge>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mediaData.availableFormats.map((format, index) => {
                const formatKey = `${format.quality}-${format.format}`;
                const isCompleted = completedDownloads.has(formatKey);
                const progress = downloadProgress[formatKey] || 0;
                const isDownloading = progress > 0 && progress < 100;
                const FormatIcon = getFormatIcon(format.format);

                return (
                  <Card key={index} className="bg-white/5 border-white/10">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-2">
                          <FormatIcon className="w-5 h-5 text-white" />
                          <span className="text-white font-medium">{format.format.toUpperCase()}</span>
                        </div>
                        <Badge className={`${getQualityBadgeColor(format.quality)} text-white`}>
                          {format.quality}
                        </Badge>
                      </div>
                      
                      <div className="text-white/70 text-sm mb-4">
                        Size: {format.size}
                      </div>

                      {isDownloading && (
                        <div className="mb-3">
                          <div className="flex justify-between text-sm text-white/70 mb-1">
                            <span>Downloading...</span>
                            <span>{Math.round(progress)}%</span>
                          </div>
                          <div className="w-full bg-white/20 rounded-full h-2">
                            <div 
                              className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all duration-300"
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                        </div>
                      )}

                      <Button
                        onClick={() => handleDownload(format)}
                        disabled={isDownloading || isCompleted}
                        className={`w-full ${
                          isCompleted 
                            ? 'bg-green-500 hover:bg-green-600' 
                            : 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600'
                        }`}
                      >
                        {isCompleted ? (
                          <>
                            <Check className="w-4 h-4 mr-2" />
                            Downloaded
                          </>
                        ) : isDownloading ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Downloading...
                          </>
                        ) : (
                          <>
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Instructions */}
      <Card className="bg-white/5 backdrop-blur-sm border-white/10">
        <CardContent className="p-4">
          <p className="text-white/70 text-sm text-center">
            Simply paste a URL above and we'll automatically fetch the media information and available download formats. 
            Select your preferred quality and format, then click download!
          </p>
        </CardContent>
      </Card>
    </div>
  );
}